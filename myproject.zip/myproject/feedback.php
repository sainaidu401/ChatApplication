<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"
    />
    <link rel="stylesheet" href="styles.css" />
    <title>Game.ing</title>
</head>
<body>
    <nav>
        <div class="nav__header">
            <div class="nav__logo">
                <a href="index.html" class="logo">Game<span>.ing</span></a>
            </div>
            <div class="nav__menu__btn" id="menu-btn">
                <i class="ri-menu-line"></i>
            </div>
        </div>
        <ul class="nav__links" id="nav-links">
            <li><a href="index.html">Home</a></li>
            <li><a href="index.html">Categories</a></li>
            <li><a href="index.html">Games</a></li>
            <li><a href="index.html">About Us</a></li>
            <li><a href="index.html">Join Us</a></li>
        </ul>
    </nav>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap");
        body {
            font-family: "poppins", sans-serif;
            margin: 20px;
            padding: 80px;
            margin-top: 20px;
        }
        h1 {
            text-align: center;
            margin-top: 80px;
        }
        .feedback-form {
            max-width: 1000px;
            margin: 0 auto;
            max-height: 800px;
            width: 100%;
           
        }
        .form-group {
            margin-bottom: 20px;
        
        }
        .form-group label {
            display:flexbox;
            font-weight: bold;

        }
        .form-group textarea {
            width: 100%;
            height: 200px;
            resize: horizontal;
            
        }
        .form-group input[type="submit"] {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
        }
        .form-group input[type="submit"]:hover {
            background-color: #0056b3;
        }
        input{
            height:40px;
            width: 400px;;
        }
    </style>
    <h1>User Feedback</h1>
    <div class="feedback-form">
        <form action="feeddata.php" method="POST" id="feedbackForm">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="feedback">Feedback:</label>
                <textarea id="feedback" name="feedback" required></textarea>
            </div>
            <div class="form-group">
                <input type="submit" value="Submit Feedback">
            </div>
        </form>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('feedbackForm');

            form.addEventListener('submit', function(event) {
                event.preventDefault(); // Prevent the default form submission

                // Get the values entered by the user
                const name = document.getElementById('name').value;
                const email = document.getElementById('email').value;
                const feedback = document.getElementById('feedback').value;

                // Send form data to backend using fetch API
                fetch(form.action, {
                    method: form.method,
                    body: new FormData(form)
                })
                .then(response => {
                    if (response.ok) {
                        // Feedback submitted successfully
                        alert(`Thanks for your feedback, ${name}!`);
                        form.reset(); // Reset the form
                    } else {
                        // Feedback submission failed
                        alert('Error submitting feedback. Please try again later.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error submitting feedback. Please try again later.');
                });
            });
        });
    </script>
    <footer class="footer">
    <div class="section__container footer__container">
      <div class="footer__col">
        <div class="footer__logo">
          <a href="#" class="logo">Game.<span>ing</span></a>
        </div>
        <p>
          Our platform is your passport to seamless Gaming,and hassel free 
          Enjoyment!
        </p>
      </div>
      <div class="footer__col">
        <h4>New Here?</h4>
        <ul class="footer__links">
          <li><a href="#">About</a></li>
          <li><a href="#">Journey</a></li>
          <li><a href="#">Mobile</a></li>
        </ul>
      </div>
      <div class="footer__col">
        <h4>Contact</h4>
        <ul class="footer__links">
          <li><a href="faq.html">Help/FAQ</a></li>
          <li><a href="#">Feedback</a></li>
          <li><a href="#">Affiliates</a></li>
        </ul>
      </div>
      <div class="footer__col">
        <ul class="footer__socials">
          <li>
            <a href="https://www.facebook.com/"><i class="ri-facebook-fill"></i></a>
          </li>
          <li>
            <a href="https://www.instagram.com/"><i class="ri-instagram-line"></i></a>
          </li>
          <li>
            <a href="https://twitter.com/?lang-en="><i class="ri-twitter-fill"></i></a>
          </li>
        </ul>
        <h5>Discover our app</h5>
        <div class="footer__discover">
          <a href="https://play.google.com/store/games?device=windows"><img src="logo-play-store-2048.png" alt="discover" /></a>
          <a href="https://www.apple.com/app-store/"><img src="appstore.png" alt="discover" /></a>
        </div>
      </div>
    </div>
    <div class="footer__bar">  
</body>
</html>
